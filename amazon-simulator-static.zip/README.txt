Static Site Package (Amazon UI Simulator)

Contents:
- index.html : single-file React + Tailwind (CDN) app

How to deploy:
- Upload the entire folder (or the zip contents) to any static host (Netlify, Vercel static, GitHub Pages, S3).
- Ensure the host serves index.html at the site root.

Notes:
- This app loads React, ReactDOM, Tailwind, and Babel from CDNs at runtime.
- If the site is used in restricted networks, consider bundling with Vite later.
